#include "so_long.h"

int	main(void)
{
	void	*mlx;

	mlx = mlx_init();
}